export function initNavigation() {
  const page = document.querySelector("[data-page]")?.dataset.page;

  document.querySelectorAll("[data-page].tabs a, .tabs a[data-page]").forEach(link => {
    if (link.dataset.page === page) link.classList.add("active");
  });
}

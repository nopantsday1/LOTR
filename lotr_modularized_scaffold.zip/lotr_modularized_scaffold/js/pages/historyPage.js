import { state } from "../core/state.js";

export function initHistoryPage() {
  const list = document.getElementById("historyList");
  const search = document.getElementById("historySearch");
  if (!list) return;

  function render() {
    const q = (search?.value || "").toLowerCase();
    const rows = state.history.filter(h => JSON.stringify(h).toLowerCase().includes(q));
    list.innerHTML = rows.map(h => `<article class="card"><pre>${escapeHtml(JSON.stringify(h, null, 2))}</pre></article>`).join("");
  }

  search?.addEventListener("input", render);
  document.getElementById("historyClearSearch")?.addEventListener("click", () => {
    search.value = "";
    render();
  });

  render();
  window.addEventListener("lotr:dataChanged", render);
}

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, c => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#039;",
  }[c]));
}

import { state } from "../core/state.js";
import { CIVS } from "../core/constants.js";
import { overallElo, civElo } from "../elo/elo.js";

export function initPlayersPage() {
  const tbody = document.getElementById("playersTable");
  const civFilter = document.getElementById("civFilter");
  if (!tbody) return;

  if (civFilter && civFilter.children.length <= 1) {
    for (const civ of CIVS) {
      const option = document.createElement("option");
      option.value = civ.id;
      option.textContent = civ.name;
      civFilter.append(option);
    }
  }

  function render() {
    tbody.innerHTML = state.players
      .slice()
      .sort((a, b) => overallElo(b) - overallElo(a))
      .map(player => {
        const civs = CIVS.map(c => `${c.id.toUpperCase()}: ${civElo(player, c.id)}`).join(" · ");
        return `
          <tr>
            <td>${player.name || ""}</td>
            <td>${overallElo(player)}</td>
            <td>${civs}</td>
            <td>${player.wins || 0}</td>
            <td>${player.losses || 0}</td>
            <td>${player.profileId || ""}</td>
          </tr>
        `;
      }).join("");
  }

  render();
  window.addEventListener("lotr:dataChanged", render);
}
